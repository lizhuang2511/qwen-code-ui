#!/usr/bin/env python3
"""
Example script demonstrating usage of the Qwen Python wrapper.
"""

from qwen_python_wrapper import QwenPythonWrapper, QwenCLIError

def main():
    # Initialize the wrapper
    wrapper = QwenPythonWrapper()

    # Check if credentials are available
    if not wrapper.check_credentials():
        print("❌ Qwen CLI credentials not found at ~/.qwen/oauth_creds.json")
        print("Please authenticate using the 'qwen' command first.")
        return
    else:
        print("✅ Qwen CLI credentials found")

    # Example 1: Simple query
    print("\n--- Simple Query ---")
    try:
        response = wrapper.simple_query("What is the capital of France?")
        print(f"Response: {response}")
    except QwenCLIError as e:
        print(f"Error: {e}")

    # Example 2: Query with specific model
    print("\n--- Query with specific model ---")
    try:
        response = wrapper.simple_query("Translate 'Hello, World!' to French", model="gpt-4")
        print(f"Response: {response}")
    except QwenCLIError as e:
        print(f"Error: {e}")

    # Example 3: JSON format response
    print("\n--- JSON Format Query ---")
    try:
        response = wrapper.json_query("Explain quantum computing in simple terms")
        print(f"JSON Response: {response}")
    except QwenCLIError as e:
        print(f"Error: {e}")

    # Example 4: Chat session simulation
    print("\n--- Chat Session ---")
    try:
        messages = [
            {"role": "user", "content": "What is Python?"},
            {"role": "assistant", "content": "Python is a high-level programming language."},
            {"role": "user", "content": "What are its main features?"}
        ]
        response = wrapper.chat_session(messages)
        print(f"Chat Response: {response}")
    except QwenCLIError as e:
        print(f"Chat Error: {e}")

if __name__ == "__main__":
    main()