#!/usr/bin/env python3
"""
Python wrapper for the qwen CLI to handle input and output through codes.

This module provides both a Python API and command-line functionality to interact
with the qwen CLI, allowing programmatic access to qwen's capabilities.

The wrapper handles:
- Direct execution of qwen CLI commands
- Input/output processing
- Credential management
- JSON and stream formats for structured interaction
"""

import json
import os
import subprocess
import sys
from typing import Optional, Dict, Any, Union, List


class QwenCLIError(Exception):
    """Exception raised when the Qwen CLI encounters an error."""
    pass


class QwenPythonWrapper:
    """
    Python wrapper for the Qwen CLI to handle input and output programmatically.
    """

    def __init__(self, cli_path: str = "qwen", credentials_path: str = "~/.qwen/oauth_creds.json"):
        """
        Initialize the Qwen Python wrapper.

        Args:
            cli_path: Path to the qwen CLI executable
            credentials_path: Path to the OAuth credentials file
        """
        self.cli_path = cli_path
        self.credentials_path = os.path.expanduser(credentials_path)

    def _run_command(
        self,
        args: List[str],
        input_text: Optional[str] = None,
        timeout: int = 300
    ) -> subprocess.CompletedProcess:
        """
        Run a qwen CLI command with the specified arguments.

        Args:
            args: List of command-line arguments to pass to qwen
            input_text: Optional input text to pass via stdin
            timeout: Command timeout in seconds

        Returns:
            CompletedProcess instance with command results

        Raises:
            QwenCLIError: If the command fails
        """
        try:
            # Prepare the command
            cmd = [self.cli_path] + args

            # Execute the command
            result = subprocess.run(
                cmd,
                input=input_text,
                text=True,
                capture_output=True,
                timeout=timeout,
                check=False  # We'll handle errors manually
            )

            # Check for errors
            if result.returncode != 0:
                error_msg = result.stderr if result.stderr else result.stdout
                raise QwenCLIError(f"Qwen CLI error (exit code {result.returncode}): {error_msg}")

            return result
        except subprocess.TimeoutExpired:
            raise QwenCLIError(f"Qwen CLI command timed out after {timeout} seconds")
        except FileNotFoundError:
            raise QwenCLIError(f"Qwen CLI not found at path: {self.cli_path}")

    def check_credentials(self) -> bool:
        """
        Check if OAuth credentials exist at the expected location.

        Returns:
            True if credentials exist, False otherwise
        """
        return os.path.exists(self.credentials_path)

    def simple_query(self, prompt: str, model: Optional[str] = None) -> str:
        """
        Send a simple query to qwen and return the response.

        Args:
            prompt: The input prompt to send to qwen
            model: Optional model name to use

        Returns:
            The response from qwen as a string
        """
        args = ["--prompt", prompt]
        if model:
            args.extend(["--model", model])

        result = self._run_command(args)
        return result.stdout

    def stream_json_query(self, prompt: str, include_partial: bool = False) -> Dict[str, Any]:
        """
        Send a query to qwen using stream-json format and return structured response.

        Note: This requires the CLI to support stream-json format, which might not be available
        in all versions. This method may raise an error if the format is not supported.

        Args:
            prompt: The input prompt to send to qwen
            include_partial: Whether to include partial messages in the response

        Returns:
            Parsed JSON response from qwen
        """
        args = [
            "--prompt", prompt,
            "--output-format", "stream-json"
        ]
        if include_partial:
            args.extend(["--include-partial", "true"])

        try:
            result = self._run_command(args)

            # Parse the JSON response
            # Stream JSON format might have multiple JSON lines, so we'll parse the last complete one
            lines = result.stdout.strip().split('\n')
            json_objects = []

            for line in lines:
                line = line.strip()
                if line:
                    try:
                        json_obj = json.loads(line)
                        json_objects.append(json_obj)
                    except json.JSONDecodeError:
                        continue

            # Return the last JSON object which should contain the final response
            if json_objects:
                return json_objects[-1]

            raise QwenCLIError("No valid JSON response found in output")
        except QwenCLIError as e:
            # If stream-json is not supported, try regular json format instead
            if "stream-json" in str(e) or "Choices" in str(e):
                print("Warning: stream-json format not supported, using json format instead.")
                return self.json_query(prompt)
            else:
                raise e

    def json_query(self, prompt: str) -> Dict[str, Any]:
        """
        Send a query to qwen using JSON format and return structured response.

        Args:
            prompt: The input prompt to send to qwen

        Returns:
            Parsed JSON response from qwen
        """
        args = ["--prompt", prompt, "--output-format", "json"]
        result = self._run_command(args)

        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as e:
            raise QwenCLIError(f"Failed to parse JSON response: {e}\nOutput: {result.stdout}")

    def chat_session(self, messages: List[Dict[str, str]]) -> str:
        """
        Start a chat session with a series of messages.
        This is more limited than the interactive UI but allows for basic session-like behavior.

        Args:
            messages: List of messages in the format [{"role": "user", "content": "text"}, ...]

        Returns:
            The response from qwen as a string
        """
        # Combine all message content as a single prompt
        full_prompt = "\n".join([f"{msg['role']}: {msg['content']}" for msg in messages])
        return self.simple_query(full_prompt)


def main():
    """
    Main function to handle command-line usage of the wrapper.
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="Python wrapper for Qwen CLI - interact with the qwen model programmatically"
    )
    parser.add_argument(
        "prompt",
        nargs="?",
        help="The prompt to send to qwen. If not provided, will show credential status"
    )
    parser.add_argument(
        "--model",
        help="Model to use for the request"
    )
    parser.add_argument(
        "--output-format",
        choices=["text", "json"],
        default="text",
        help="Format for the output"
    )
    parser.add_argument(
        "--credentials",
        action="store_true",
        help="Check credential status"
    )

    args = parser.parse_args()

    # Create wrapper instance
    wrapper = QwenPythonWrapper()

    # Check credentials if requested
    if args.credentials:
        if wrapper.check_credentials():
            print("✓ Qwen CLI credentials found")
            sys.exit(0)
        else:
            print("✗ Qwen CLI credentials not found at ~/.qwen/oauth_creds.json")
            sys.exit(1)

    # If no prompt provided, just check credentials status
    if not args.prompt:
        if wrapper.check_credentials():
            print("Qwen CLI credentials are available. You can now make requests.")
        else:
            print("Qwen CLI credentials not found. Please authenticate using 'qwen' command first.")
        return

    # Make the request based on output format
    try:
        if args.output_format == "json":
            response = wrapper.json_query(args.prompt)
            print(json.dumps(response, indent=2))
        elif args.output_format == "stream-json":
            response = wrapper.stream_json_query(args.prompt)
            print(json.dumps(response, indent=2))
        else:  # text format
            response = wrapper.simple_query(args.prompt, args.model)
            print(response)
    except QwenCLIError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()